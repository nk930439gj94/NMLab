class NotEnoughFundsError(Exception):
    pass


class NotFoundTransaction(Exception):
    pass
